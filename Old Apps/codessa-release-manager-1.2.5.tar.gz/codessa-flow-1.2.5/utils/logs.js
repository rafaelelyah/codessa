import fs from 'fs';
import path from 'path';

/**
 * 🔹 Salva versão e commit no log do módulo
 * @param {string} modulePath - Caminho do módulo
 * @param {string} version - Versão do módulo
 * @param {string} commit - Mensagem de commit
 * @param {object} extra - Campos adicionais (title, added, removed, changed, notes)
 */
export function logVersion(modulePath, version, commit, extra = {}) {
  const logPath = path.join(modulePath, 'version-log.json');
  let log = [];

  if (fs.existsSync(logPath)) {
    log = JSON.parse(fs.readFileSync(logPath, 'utf-8'));
  }

  log.push({
    version,
    date: new Date().toISOString(),
    commit,
    ...extra
  });

  fs.writeFileSync(logPath, JSON.stringify(log, null, 2));
}
