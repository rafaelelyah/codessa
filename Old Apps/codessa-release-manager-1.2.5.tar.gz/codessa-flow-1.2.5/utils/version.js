import fs from 'fs';
import path from 'path';

export function bumpVersion(modulePath, type, preRelease) {
  const pkgPath = path.join(modulePath, 'package.json');

  if (!fs.existsSync(pkgPath)) {
    throw new Error(`package.json não encontrado em ${modulePath}`);
  }

  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
  const rawVersion = pkg.version || '0.0.0';
  const [baseVersion] = rawVersion.split('-');
  const [major, minor, patch] = baseVersion.split('.').map(Number);

  if ([major, minor, patch].some(isNaN)) {
    throw new Error(`Versão inválida no package.json: "${rawVersion}"`);
  }

  let newVersion;
  switch (type) {
    case 'major':
      newVersion = `${major + 1}.0.0`;
      break;
    case 'minor':
      newVersion = `${major}.${minor + 1}.0`;
      break;
    case 'patch':
    default:
      newVersion = `${major}.${minor}.${patch + 1}`;
      break;
  }

  if (preRelease) {
    newVersion += `-${preRelease}`;
  }

  pkg.version = newVersion;
  fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2));

  return newVersion;
}
