import fs from 'fs';
import path from 'path';

/**
 * 🔹 Gera o markdown do badge de versão
 * @param {string} version - Versão do módulo (ex: 0.9.14-alpha)
 * @param {string} color - Cor do badge (ex: blue, orange)
 * @param {string} label - Texto do badge (default: "Versão")
 * @returns {string} Markdown do badge
 */
export function generateBadge(version, color, label = 'Versão') {
  const formattedVersion = version.includes('-')
    ? version.replace('-', '--')
    : version;

  return `![${label}](https://img.shields.io/badge/${encodeURIComponent(label.toLowerCase())}-${encodeURIComponent(formattedVersion)}-${color}.svg)`;
}

/**
 * 🔹 Insere ou atualiza o badge no topo de um arquivo
 * @param {string} filePath - Caminho do arquivo Markdown
 * @param {string} badgeMarkdown - Markdown do badge
 */
export function insertBadge(filePath, badgeMarkdown) {
  if (!fs.existsSync(filePath)) return;

  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n');

  // Remove qualquer badge existente no topo
  const filtered = lines.filter(line =>
    !/^!\[(Versão|Release)\]\(https:\/\/img\.shields\.io\/badge\//.test(line)
  );

  const updated = [badgeMarkdown.trim(), '', ...filtered].join('\n');
  fs.writeFileSync(filePath, updated);
}

/**
 * 🔹 Gera âncora compatível com GitHub
 * @param {string} title - Título do cabeçalho
 * @returns {string} Âncora normalizada
 */
function generateAnchor(title) {
  return title
    .replace(/^[^\p{L}\p{N}]+/u, '') // remove emojis no início
    .trim()
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s-]/gu, '') // remove símbolos, mantém letras acentuadas
    .replace(/\s+/g, '-');
}

/**
 * 🔹 Gera sumário com base nos títulos ## do arquivo
 * @param {string} filePath - Caminho do arquivo Markdown
 * @returns {string} Markdown do sumário
 */
export function generateTOC(filePath) {
  if (!fs.existsSync(filePath)) return '';

  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n');

  const tocLines = lines
    .filter(line => line.startsWith('## '))
    .map(line => {
      const title = line.replace(/^##\s*/, '').trim();
      const anchor = generateAnchor(title);
      return `- [${title}](#${anchor})`;
    });

  return tocLines.length
    ? `## 📚 Sumário\n\n${tocLines.join('\n')}\n`
    : '';
}

/**
 * 🔹 Insere ou atualiza o sumário abaixo do badge
 * @param {string} filePath - Caminho do arquivo Markdown
 * @param {string} tocMarkdown - Markdown do sumário
 */
export function insertTOC(filePath, tocMarkdown) {
  if (!fs.existsSync(filePath) || !tocMarkdown.trim()) return;

  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n');

  // Remove sumário existente
  const tocStart = lines.findIndex(line => line.includes('## 📚 Sumário'));
  let filtered = lines;

  if (tocStart !== -1) {
    const tocSlice = lines.slice(tocStart);
    const nextHeaderIndex = tocSlice.findIndex((line, i) => i > 0 && line.startsWith('## '));
    const tocEnd = nextHeaderIndex !== -1 ? tocStart + nextHeaderIndex : lines.length;
    filtered = [...lines.slice(0, tocStart), ...lines.slice(tocEnd)];
  }

  // Inserir após o badge
  const badgeIndex = filtered.findIndex(line =>
    /^!\[(Versão|Release)\]\(https:\/\/img\.shields\.io\/badge\//.test(line)
  );
  const insertIndex = badgeIndex >= 0 ? badgeIndex + 2 : 0;

  const updated = [
    ...filtered.slice(0, insertIndex),
    tocMarkdown.trim(),
    '',
    ...filtered.slice(insertIndex)
  ].join('\n');

  fs.writeFileSync(filePath, updated);
}
