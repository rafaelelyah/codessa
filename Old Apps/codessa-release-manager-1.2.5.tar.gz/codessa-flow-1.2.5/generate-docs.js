import path from 'path';
import fs from 'fs';
import modulesMap from './config/modules.json' assert { type: 'json' };

import {
  generateBadge,
  insertBadge,
  generateTOC,
  insertTOC
} from './utils/docs.js';

const releaseColors = {
  alpha: 'orange',
  beta: 'yellow',
  rc: 'purple',
  canary: 'red',
  preview: 'gray',
  dev: 'lightgray',
  stable: 'blue'
};

function getVersionLog(modulePath) {
  const logPath = path.join(modulePath, 'version-log.json');
  if (!fs.existsSync(logPath)) {
    console.warn(`⚠️ version-log.json não encontrado em ${modulePath}`);
    return null;
  }

  try {
    return JSON.parse(fs.readFileSync(logPath, 'utf-8'));
  } catch (err) {
    console.error(`❌ Erro ao ler version-log.json em ${modulePath}:`, err.message);
    return null;
  }
}

function getReleaseColor(version) {
  const [, suffix] = version.split('-');
  return releaseColors[suffix] || releaseColors.stable;
}

function updateDocsForModule(moduleKey, moduleConfig) {
  const modulePath = path.resolve(moduleConfig.path);
  const versionLog = getVersionLog(modulePath);

  const lastEntry = Array.isArray(versionLog) ? versionLog.at(-1) : null;
  if (!lastEntry || !lastEntry.version) {
    console.warn(`⚠️ Versão não encontrada para ${moduleConfig.label}`);
    return;
  }

  const { version, commit } = lastEntry;
  const color = getReleaseColor(version);
  const badge = generateBadge(version, color);

  const readmePath = path.join(modulePath, 'README.md');

  let updated = false;

  if (fs.existsSync(readmePath)) {
    insertBadge(readmePath, badge);
    const toc = generateTOC(readmePath);
    insertTOC(readmePath, toc);
    console.log(`📘 README.md atualizado para ${moduleConfig.label}`);
    updated = true;
  } else {
    console.warn(`⚠️ README.md não encontrado para ${moduleConfig.label}`);
  }

  if (!updated) {
    console.log(`ℹ️ Nenhum arquivo de documentação atualizado para ${moduleConfig.label}`);
  }
}


console.log('📚 Atualizando documentação dos módulos...\n');

for (const [moduleKey, moduleConfig] of Object.entries(modulesMap)) {
  updateDocsForModule(moduleKey, moduleConfig);
}

console.log('\n🎉 Documentação sincronizada com sucesso!');
