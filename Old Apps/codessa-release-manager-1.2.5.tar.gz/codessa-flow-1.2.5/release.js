import path from 'path';
import fs from 'fs';
import os from 'os';
import { execSync } from 'child_process';
import inquirer from 'inquirer';

import { bumpVersion } from './utils/version.js';
import { logVersion } from './utils/logs.js';
import { generateBadge, insertBadge, generateTOC, insertTOC } from './utils/docs.js';

const releaseColors = {
  alpha: 'orange',
  beta: 'yellow',
  rc: 'purple',
  canary: 'red',
  preview: 'gray',
  dev: 'lightgray',
  stable: 'blue'
};

function getReleaseColor(version) {
  const [, suffix] = version.split('-');
  return releaseColors[suffix] || releaseColors.stable;
}

export async function runRelease({
  type,
  moduleKey,
  preRelease,
  commit,
  title,
  added = [],
  removed = [],
  changed = [],
  notes = '',
  modulesMap // ✅ Recebido do CLI
}) {
  // 🔍 Validação de entrada
  if (!['patch', 'minor', 'major'].includes(type)) {
    throw new Error(`❌ Tipo de versão inválido: "${type}". Use patch, minor ou major.`);
  }

  if (!moduleKey || !modulesMap[moduleKey]) {
    throw new Error(`❌ Módulo "${moduleKey}" não encontrado.`);
  }

  const moduleConfig = modulesMap[moduleKey];
  const moduleLabel = moduleConfig.label;
  const modulePath = path.resolve(moduleConfig.path);

  // 🛠️ Build com Vite (se existir)
  function deployBuild() {
    const viteConfigPath = path.join(modulePath, 'vite.config.js');
    if (!fs.existsSync(viteConfigPath)) {
      console.log(`⚠️ ${moduleLabel} não possui build com Vite. Pulando etapa de build.`);
      return;
    }

    console.log(`🔧 Gerando build para ${moduleLabel}...`);
    execSync('npx vite build', { cwd: modulePath, stdio: 'inherit' });

    const distPath = path.join(modulePath, 'dist');
    const publicPath = path.join(modulePath, 'public');

    if (fs.existsSync(publicPath)) {
      fs.rmSync(publicPath, { recursive: true, force: true });
    }

    fs.cpSync(distPath, publicPath, { recursive: true });
    console.log(`🚀 Build copiado para ${moduleConfig.path}/public/`);
  }

  // 📦 Etapas do release
  const newVersion = bumpVersion(modulePath, type, preRelease);
  logVersion(modulePath, newVersion, commit, { title, added, removed, changed, notes });
  deployBuild();

  // 🏷️ Badge e TOC
  const badge = generateBadge(newVersion, getReleaseColor(newVersion), 'Release');
  const readmePath = path.join(modulePath, 'README.md');

  if (fs.existsSync(readmePath)) {
    insertBadge(readmePath, badge);
    const toc = generateTOC(readmePath);
    insertTOC(readmePath, toc);
    console.log(`📘 README.md atualizado para ${moduleLabel}`);
  }

  console.log(`\n🎉 Release concluído para ${moduleLabel} — versão ${newVersion}`);

  // 🧩 Interação para push opcional
  const { confirmPush } = await inquirer.prompt([
    {
      type: 'confirm',
      name: 'confirmPush',
      message: `Deseja executar o push para o repositório ${moduleLabel} agora?`,
      default: false
    }
  ]);

  if (!confirmPush) {
    console.log(`ℹ️ Push manual pode ser feito com: git push && git push --tags dentro de ${moduleConfig.path}`);
    return;
  }

  // 🧠 Detecção de sistema e execução do script correto
  try {
    const isWindows = os.platform() === 'win32';
    const scriptName = isWindows ? 'push-release.bat' : 'push-release.sh';
    const scriptPath = path.join(modulePath, scriptName);

    if (!fs.existsSync(scriptPath)) {
      console.error(`❌ Script de push não encontrado em: ${scriptPath}`);
      return;
    }

    console.log(`🧠 Sistema detectado: ${isWindows ? 'Windows' : 'Unix-like'}`);

    if (isWindows) {
      execSync(`"${scriptPath}"`, {
        cwd: modulePath,
        stdio: 'inherit',
        shell: 'cmd.exe'
      });
    } else {
      execSync(`bash "${scriptPath}"`, {
        cwd: modulePath,
        stdio: 'inherit'
      });
    }
  } catch (err) {
    console.error(`❌ Falha ao executar ${scriptName}:`, err.message);
  }
}
