![Release](https://img.shields.io/badge/release-1.2.5-blue.svg)

## 📚 Sumário

- [Funcionalidades](#funcionalidades)
- [Instalação via NPM](#instalação-via-npm)
- [Uso via CLI](#uso-via-cli)
- [Estrutura esperada por módulo](#estrutura-esperada-por-módulo)
- [Mapeamento de módulos](#mapeamento-de-módulos)
- [Adaptação para outros projetos](#adaptação-para-outros-projetos)
- [Histórico](#histórico)
- [Autor](#autor)
- [Licença](#licença)
- [Contribuições](#contribuições)

# Codessa Release Manager

Gerenciador de versões modular para projetos multi-pacote. Parte do ecossistema **Codessa Studio**.

---

## Funcionalidades

- Atualização semântica de versões (`patch`, `minor`, `major`)
- Suporte a pré-releases (`alpha`, `beta`, `rc`, etc.)
- Geração automática de `version-log.json` e `CHANGELOG.md`
- Build com Vite (quando aplicável)
- Commit, tag e push via Git
- Atualização automática do `README.md` com badge e sumário
- Changelog global do Codessa Studio

---

## Instalação via NPM

Você pode instalar e usar o Codessa Release Manager diretamente via NPM:

```bash
npm install -g codessa-release-manager
```

Ou usar sem instalar globalmente:

```bash
npx codessa-release setup
```

O comando setup detecta os módulos versionáveis no projeto e gera o arquivo codessa-modules.json na raiz.

## Uso via CLI

Após o setup, execute:

```bash
npx codessa-release
```

Você será guiado por um menu interativo para:

- Escolher o módulo
- Definir o tipo de versão (`patch`, `minor`, `major`)
- Escolher o tipo de release (`alpha`, `beta`, `rc`, etc.)
- Escrever o comentário do release

O script executa automaticamente:

- Bump de versão
- Registro no `version-log.json`
- Build com Vite (se aplicável)
- Atualização do sumário no `README.md`
- Execução opcional do push via Git

## Estrutura esperada por módulo

Cada módulo deve conter:

- `package.json` com campo version
- `version-log.json` para histórico de versões
- `README.md` para exibir badge e sumário
- (Opcional) `vite.config.js` para build com Vite
- Scripts `push-release.sh` e `push-release.bat` para publicação via Git
- Esses scripts devem conter os comandos de git commit, git tag e git push conforme sua estratégia de publicação.

## Mapeamento de módulos

O arquivo `codessa-modules.json` define os módulos disponíveis:

```json
{
  "studio": {
    "label": "Codessa Studio",
    "path": "."
  },
  "interface": {
    "label": "Codessa Interface",
    "path": "codessa-interface"
  },
  "release": {
    "label": "Codessa Release Manager",
    "path": "codessa-release-manager"
  }
}
```

## Adaptação para outros projetos
Para usar o Codessa Release Manager em outro repositório:

Instale via NPM:
```bash
npm install -g codessa-release-manager
```

Execute o setup:
```bash
npx codessa-release setup
```
Certifique-se de que cada módulo tenha:

- `package.json` com versão
- `version-log.json`
- Scripts de push (.sh e .bat)
- `README.md` para badge e sumário

Execute o CLI:
```bash
npx codessa-release
```

## Histórico
Todos os releases são registrados em:

version-log.json dentro de cada módulo

## Autor
Desenvolvido por Rafael Elyah Parte do ecossistema Codessa Studio.

## Licença

Este módulo segue a licença definida no repositório principal do [Codessa Studio](https://github.com/rafaelelyah/codessa-studio).  

---

## Contribuições

Sugestões, melhorias e correções são bem-vindas.  
Você pode abrir uma issue ou enviar um pull request com suas propostas.